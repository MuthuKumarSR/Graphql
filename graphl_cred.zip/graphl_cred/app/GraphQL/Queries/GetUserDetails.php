<?php

namespace App\GraphQL\Queries;
use App\Models\User;
use GraphQL\Error\Error;

final class GetUserDetails
{
    /**
     * @param  null  $_
     * @param  array{}  $args
     */
    public function __invoke($_, array $args)
    {
        // TODO implement the resolver
      
        $output['result'] = 'Login';
        return $output;
    }
}
